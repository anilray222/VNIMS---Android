VNIMS Android WebView project

Homepage: https://myvnims.ai.studio/
Application ID: org.vnims.app
App label: VNIMS

BUILD THE APK
1. Install Android Studio: https://developer.android.com/studio
2. Extract this ZIP file.
3. In Android Studio choose File > Open and select the extracted VNIMS folder.
4. Allow Gradle sync and install the suggested Android SDK Platform 35 / Build Tools if prompted.
5. Connect an Android phone or use an emulator and press Run to test.
6. For a shareable APK, choose Build > Generate Signed Bundle / APK > APK.
7. Create and securely back up a keystore. Select the release variant and finish.
8. Find the generated APK under app/release/ (or the output path shown by Android Studio).

NOTES
- This is a WebView wrapper: the VNIMS website remains hosted online and requires internet access.
- The launcher icon included is a temporary VNIMS-colour placeholder. Replace it with your official logo using Image Asset in Android Studio.
- Test sign-in, payment, file upload, downloads, camera/microphone and any AI features on a real phone before distributing widely. Google sign-in may require a browser-based OAuth flow and may not work embedded in WebView.
- Keep the signing keystore and passwords safe; future updates must use the same signing key.
